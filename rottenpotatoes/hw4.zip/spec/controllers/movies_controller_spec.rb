require 'rails_helper'

RSpec.describe MoviesController, type: :controller do

end
